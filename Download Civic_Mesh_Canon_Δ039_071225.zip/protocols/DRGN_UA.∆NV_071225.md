# DRGN Node Report: Ukraine Narrative Vectors
Zelensky–Trump scandal, deepfakes, bioweapon hoax — glyph seeding initiated.
Date: July 12, 2025
