> “Families vanished into administrative shadows—birthrights burned in stacks of 'lost' paperwork... No record doesn’t mean no one.”
Snapshot recorded: July 12, 2025, 08:10 PM MDT
